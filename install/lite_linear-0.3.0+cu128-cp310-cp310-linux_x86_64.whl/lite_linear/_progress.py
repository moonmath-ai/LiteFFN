"""Progress reporter for convert operations."""

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass

from rich.progress import (
    BarColumn,
    DownloadColumn,
    ProgressColumn,
    Task,
    TaskID,
    TaskProgressColumn,
)
from rich.progress import (
    Progress as RichProgress,
)
from rich.text import Text


def _fmt_hms(seconds: float) -> str:
    """`MM:SS` (or `HH:MM:SS` for >1h). Matches tqdm's compact style."""
    s = int(seconds)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    return f"{h:d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def _fmt_rate(bytes_per_second: float | None) -> str:
    """Auto-scaled bytes/sec → `XB/s`, `XKB/s`, `XMB/s`, `XGB/s`."""
    if bytes_per_second is None:
        return "?"
    for unit, scale in (("GB/s", 1e9), ("MB/s", 1e6), ("KB/s", 1e3)):
        if bytes_per_second >= scale:
            return f"{bytes_per_second / scale:.1f}{unit}"
    return f"{bytes_per_second:.0f}B/s"


class _TqdmTimingColumn(ProgressColumn):
    """tqdm-style `[elapsed<remaining, rate]` — compact alternative to
    rich's separate TimeElapsed/TimeRemaining/TransferSpeed columns."""

    def render(self, task: Task) -> Text:
        elapsed = _fmt_hms(task.elapsed or 0)
        remaining = (
            _fmt_hms(task.time_remaining) if task.time_remaining is not None else "?"
        )
        speed = task.finished_speed or task.speed
        return Text(f"[{elapsed}<{remaining}, {_fmt_rate(speed)}]")


class _DecomposeStatusColumn(ProgressColumn):
    """Right-side status: `decomposing N/M` while a prefix's SVD runs and
    its factors are written; empty otherwise."""

    def render(self, task: Task) -> Text:
        status: str = task.fields.get("decompose_status", "")
        return Text(status, style="progress.description")


@dataclass
class _ConvertProgress:
    """Progress reporter for one convert. Construct via `start(...)`.

    Position updates count *input bytes consumed*: a chunk copied via
    sendfile advances by the chunk size, and a fully-decomposed prefix
    advances by the original weight's bytes when its last factor is
    written.

    Pass `disable=True` to silence rendering without disabling the update
    calls (they become no-ops).
    """

    bar: RichProgress
    task: TaskID
    decompose_total: int
    decompose_done: int = 0

    @classmethod
    @contextmanager
    def start(
        cls,
        name: str,
        total_bytes: int,
        decompose_total: int,
        *,
        disable: bool = False,
    ) -> Iterator["_ConvertProgress"]:
        # Format: `XX% ━━━━ done/total [elapsed<remaining, rate] decomposing N/M`.
        # No leading description (the CLI's `Wrote …` log line names the file).
        # _DecomposeStatusColumn last so its variable width doesn't shift the
        # bar horizontally as the label toggles on/off.
        bar = RichProgress(
            TaskProgressColumn(),
            BarColumn(),
            DownloadColumn(),
            _TqdmTimingColumn(),
            _DecomposeStatusColumn(),
            disable=disable,
        )
        with bar:
            task = bar.add_task(name, total=total_bytes, decompose_status="")
            yield cls(bar=bar, task=task, decompose_total=decompose_total)

    def advance(self, n: int) -> None:
        self.bar.update(self.task, advance=n)

    def clear_decompose_status(self) -> None:
        self.bar.update(self.task, decompose_status="")

    def announce_decompose(self) -> None:
        """Bump the decompose counter and refresh the right-side status."""
        self.decompose_done += 1
        self.bar.update(
            self.task,
            decompose_status=f"decomposing {self.decompose_done}/{self.decompose_total}",
        )
