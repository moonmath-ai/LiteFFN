"""Per-layer rank manifest for `lite-linear convert --manifest manifest.toml`.

A manifest pins which LiteLinear modules a model has and at what rank, in
a human-editable file format. Generate from a model in source
(`manifest_from_model`); consume at conversion time (`load_manifest`).
"""

import sys
from pathlib import Path

import tomli_w
from torch import nn

from .linear import LiteLinear

# Read path: stdlib `tomllib` on 3.11+, `tomli` backport on 3.10 (conditional dep in pyproject.toml).
if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover - exercised on 3.10 CI only
    import tomli as tomllib


ManifestDict = dict[str, int]
"""`{qualified_module_name: rank}` — the on-disk and in-memory manifest shape."""


def manifest_from_model(model: nn.Module) -> ManifestDict:
    """Walk `model.named_modules()` and return `{name: rank}` per `LiteLinear`.

    Works for a meta-device model — no forward pass required.
    """
    # `LiteLinear.rank` is a Python int set in __init__, not derived from
    # any allocated tensor, so meta-device modules still report their rank.
    return {
        name: int(module.rank)
        for name, module in model.named_modules()
        if isinstance(module, LiteLinear)
    }


def load_manifest(path: str | Path) -> ManifestDict:
    """Read a manifest TOML; require a `[ranks]` table mapping strings to ints."""
    parsed = tomllib.loads(Path(path).read_text(encoding="utf-8"))
    if "ranks" not in parsed:
        raise KeyError(
            f"Manifest {path}: missing required `[ranks]` table (got top-level keys: {sorted(parsed)})"
        )
    table = parsed["ranks"]
    if not isinstance(table, dict):
        raise TypeError(
            f"Manifest {path}: `[ranks]` must be a table, got {type(table).__name__}"
        )
    out: ManifestDict = {}
    for prefix, value in table.items():
        # Reject `bool` explicitly — it subclasses `int`, so a TOML `true`
        # would otherwise sneak through as rank 1.
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(
                f"Manifest {path}: rank for {prefix!r} must be a positive int, got {value!r}"
            )
        out[prefix] = value
    return out


def save_manifest(path: str | Path, manifest: ManifestDict) -> None:
    """Write a manifest TOML with a single `[ranks]` table."""
    for prefix, rank in manifest.items():
        if rank <= 0:
            raise ValueError(
                f"Manifest entry {prefix!r}: rank must be positive, got {rank}"
            )
    # We rely on tomli_w auto-quoting dotted/numeric keys; otherwise
    # `transformer_blocks.0` would round-trip as a nested table.
    Path(path).write_bytes(tomli_w.dumps({"ranks": dict(manifest)}).encode("utf-8"))


__all__ = ["ManifestDict", "load_manifest", "manifest_from_model", "save_manifest"]
