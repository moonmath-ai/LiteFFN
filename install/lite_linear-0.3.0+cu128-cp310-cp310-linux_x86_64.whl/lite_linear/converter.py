"""State-dict-level conversion: dense `<prefix>.weight` → LiteLinear factors.

`convert_safetensors` is the entry point (file in, file out: single
`.safetensors` or HF-sharded directory).
"""

import ctypes
import json
import logging
import math
import os
import re
import shutil
import struct
import sys
import tempfile
from collections.abc import Sequence
from contextlib import ExitStack
from dataclasses import dataclass
from pathlib import Path

import torch
from safetensors import safe_open

from ._progress import _ConvertProgress
from .calibration import load_r_matrices
from .decompose import decompose_weight

log = logging.getLogger(__name__)

# Chunk size for `os.sendfile`. Small enough for snappy ctrl-C (each chunk is
# ~60 ms on the slowest realistic storage) and a smooth bar; large enough that
# syscall overhead is invisible.
_SENDFILE_CHUNK = 16 * 1024 * 1024

# _fdatasync is Linux-only; macOS has no data/metadata separation so we use
# os.fsync there. Functionally equivalent for our durability goal.
_fdatasync = getattr(os, "fdatasync", os.fsync)

# Sibling-of-output suffix for the atomic staging file/dir. Unique enough
# (matches PyPI package name) that any path with this suffix is
# unambiguously ours, so a crashed prior run's leftover gets swept by
# `_prepare_output_paths` without an --overwrite gate.
_STAGING_SUFFIX = ".lite-linear-partial"


@dataclass(frozen=True)
class _LoraSpec:
    path: Path
    strength: float


@dataclass(frozen=True)
class _OpenLora:
    path: Path
    strength: float
    tensors: object
    keys: frozenset[str]


def _normalize_lora_specs(
    lora_paths_and_strengths: Sequence[tuple[str | Path, float]] | None,
) -> tuple[_LoraSpec, ...]:
    if not lora_paths_and_strengths:
        return ()
    specs: list[_LoraSpec] = []
    for raw_path, raw_strength in lora_paths_and_strengths:
        path = Path(raw_path)
        if not path.is_file():
            raise FileNotFoundError(
                f"LoRA checkpoint does not exist or is not a file: {path}"
            )
        if path.suffix.lower() != ".safetensors":
            raise ValueError(f"LoRA checkpoint must be a `.safetensors` file: {path}")
        specs.append(_LoraSpec(path=path, strength=float(raw_strength)))
    return tuple(specs)


def _lora_factor_key_candidates(prefix: str) -> tuple[tuple[str, str], ...]:
    """Return possible LoRA A/B key pairs for a dense weight prefix.

    model checkpoints often store dense weights under a leading ``model.``
    namespace while distilled LoRAs omit that prefix. Try the exact prefix
    first so generic checkpoints still behave as expected.
    """
    prefixes = [prefix]
    without_model = prefix.removeprefix("model.")
    if without_model != prefix:
        prefixes.append(without_model)
    return tuple((f"{p}.lora_A.weight", f"{p}.lora_B.weight") for p in prefixes)


def _find_lora_factor_keys(lora: _OpenLora, prefix: str) -> tuple[str, str] | None:
    for key_a, key_b in _lora_factor_key_candidates(prefix):
        has_a = key_a in lora.keys
        has_b = key_b in lora.keys
        if has_a and has_b:
            return key_a, key_b
        if has_a or has_b:
            missing = key_b if has_a else key_a
            raise KeyError(
                f"LoRA {lora.path} has an incomplete factor pair for {prefix!r}; "
                f"missing {missing!r}"
            )
    return None


def _fuse_lora_weight(
    W: torch.Tensor,
    *,
    prefix: str,
    loras: Sequence[_OpenLora],
) -> torch.Tensor:
    """Return ``W + sum(strength * B @ A)`` for matching LoRA factors."""
    fused: torch.Tensor | None = None
    for lora in loras:
        factor_keys = _find_lora_factor_keys(lora, prefix)
        if factor_keys is None:
            continue

        if fused is None:
            fused = W.to(dtype=torch.float32)
        key_a, key_b = factor_keys
        lora_a = lora.tensors.get_tensor(key_a).to(
            device=fused.device, dtype=torch.float32
        )
        lora_b = lora.tensors.get_tensor(key_b).to(
            device=fused.device, dtype=torch.float32
        )
        expected = (fused.shape[0], fused.shape[1])
        actual = (lora_b.shape[0], lora_a.shape[1])
        if (
            lora_a.ndim != 2
            or lora_b.ndim != 2
            or lora_a.shape[0] != lora_b.shape[1]
            or actual != expected
        ):
            raise ValueError(
                f"LoRA factors for {prefix!r} in {lora.path} do not match weight shape "
                f"{tuple(fused.shape)}: {key_a}={tuple(lora_a.shape)}, {key_b}={tuple(lora_b.shape)}"
            )
        fused.addmm_(lora_b, lora_a, alpha=lora.strength)
    return W if fused is None else fused


def _regex_to_ranks(
    shape_map: dict[str, tuple[int, ...]],
    layer_regex: str,
    rank: int,
) -> dict[str, int]:
    """Expand a Python regex + a uniform `rank` into `{prefix: rank}`.

    The regex is matched via `re.search` (unanchored) against the prefix
    (key with `.weight` stripped). Returns only 2D `<prefix>.weight`
    matches; 1D LayerNorm / RMSNorm weights are silently skipped so
    `--regex '.*'` does the obvious thing. Raises ValueError if `rank`
    is non-positive or no prefix matches.
    """
    if rank <= 0:
        raise ValueError(f"rank must be positive, got {rank}")
    pattern = re.compile(layer_regex)
    selected: set[str] = set()
    for key, shape in shape_map.items():
        if not key.endswith(".weight"):
            continue
        if len(shape) != 2:
            continue
        prefix = key[: -len(".weight")]
        if pattern.search(prefix):
            selected.add(prefix)
    if not selected:
        raise ValueError(
            f"layer_regex {layer_regex!r} did not match any 2D `<prefix>.weight` key in input"
        )
    return dict.fromkeys(selected, rank)


def _validate_ranks(
    ranks: dict[str, int],
    shape_map: dict[str, tuple[int, ...]],
) -> None:
    """Raise on any invalid entry in a `{prefix: rank}` dict.

    Checks each entry has a positive rank, a `<prefix>.weight` present
    in `shape_map`, that weight is 2D, and the rank fits in
    `min(d_out, d_in)`.

    Raises:
        ValueError: rank <= 0, non-2D weight, or rank > min(d_out, d_in).
        KeyError: prefix with no `<prefix>.weight` in `shape_map`.
    """
    for prefix, r in ranks.items():
        if r <= 0:
            raise ValueError(f"rank for {prefix!r} must be positive, got {r}")
    missing = [p for p in ranks if f"{p}.weight" not in shape_map]
    if missing:
        raise KeyError(f"prefix_ranks keys not found in input: {sorted(missing)}")
    bad_shape = [p for p in ranks if len(shape_map[f"{p}.weight"]) != 2]
    if bad_shape:
        details = ", ".join(
            f"{p} (shape={shape_map[f'{p}.weight']})" for p in bad_shape
        )
        raise ValueError(
            f"prefix_ranks point at non-2D weights (not 2D): {details}; only nn.Linear-style weights can be decomposed"
        )
    # decompose_weight would also reject, but on multi-prefix runs the error
    # lands mid-output; surfacing here keeps the I/O atomic.
    oversized = [
        (p, ranks[p], shape_map[f"{p}.weight"])
        for p in ranks
        if ranks[p] > min(shape_map[f"{p}.weight"])
    ]
    if oversized:
        details = ", ".join(
            f"{p} (rank={r}, shape={s}, max={min(s)})" for p, r, s in oversized
        )
        raise ValueError(
            f"rank exceeds min(d_out, d_in) for: {details}. Lower the rank "
            f"or switch to --manifest to pick per-prefix ranks."
        )


def _plan_conversion(
    shape_map: dict[str, tuple[int, ...]],
    *,
    layer_regex: str | None,
    rank: int | None,
    prefix_ranks: dict[str, int] | None,
) -> dict[str, int]:
    """Resolve a selection mode into a validated `{prefix: rank}` dict."""
    if prefix_ranks is not None and layer_regex is None and rank is None:
        ranks = dict(prefix_ranks)
    elif prefix_ranks is None and layer_regex is not None and rank is not None:
        ranks = _regex_to_ranks(shape_map, layer_regex, rank)
    else:
        raise ValueError(
            "Specify either `prefix_ranks` or (`layer_regex` + `rank`), not both / neither"
        )
    # Redundant for the regex branch (valid by construction); kept so the invariant survives future refactors.
    _validate_ranks(ranks, shape_map)
    return ranks


def apply_decomposition(
    state_dict: dict[str, torch.Tensor],
    ranks: dict[str, int],
    *,
    r_matrices: dict[str, torch.Tensor] | None = None,
    q_dtype: torch.dtype = torch.float8_e4m3fn,
    decompose_device: str | torch.device | None = None,
) -> dict[str, torch.Tensor]:
    """Replace each `<prefix>.weight` in `ranks` with four LiteLinear factor keys.

    Pure-functional: returns a new dict; `state_dict` is not mutated. The
    caller is responsible for ensuring each prefix has a 2D
    `<prefix>.weight` in `state_dict` with a positive rank.

    Best-fit weights: the rank-r decomposition pays off in storage and
    quality when both weight dimensions are much larger than `rank`.
    Wide-thin matrices, embeddings, or weights with rank close to
    min(dims) compress less cleanly.

    Args:
        state_dict: source dense state dict. Not mutated.
        ranks: `{prefix: rank}` for every prefix to be decomposed.
        r_matrices: optional `prefix -> R` mapping (autocorrelation
            matrix from calibration). Prefixes with an entry use the
            data-aware decomposition; the rest use plain SVD.
        q_dtype: target FP8 dtype for the Q remainder. Defaults to
            `torch.float8_e4m3fn` (NVIDIA); pass `torch.float8_e4m3fnuz`
            for AMD ROCm checkpoints.
        decompose_device: device for the decomposition math (SVD; eigh
            when an R matrix is given). The factors come back on each
            weight's original device either way.

    Returns:
        A new dict containing every passthrough key plus four factor
        keys (`<prefix>.A`, `.B`, `.Q_fp8`, `.Q_scale_inv`) for each
        prefix in `ranks`. The original `<prefix>.weight` is removed.
    """
    device = torch.device(decompose_device) if decompose_device is not None else None
    out: dict[str, torch.Tensor] = dict(state_dict)
    for prefix, r in ranks.items():
        weight_key = f"{prefix}.weight"
        W = out.pop(weight_key)
        R = r_matrices.get(prefix) if r_matrices is not None else None
        W_dec = W.to(device) if device is not None else W
        R_dec = R.to(device) if (R is not None and device is not None) else R
        # `ab_dtype=bf16` is the fused kernel's required storage dtype; pinned explicitly so the on-disk format survives a default change in decompose_weight.
        A, B, Q_fp8, Q_scale_inv = decompose_weight(
            W_dec, rank=r, R=R_dec, ab_dtype=torch.bfloat16, q_dtype=q_dtype
        )
        out[f"{prefix}.A"] = A.contiguous().to(W.device)
        out[f"{prefix}.B"] = B.contiguous().to(W.device)
        out[f"{prefix}.Q_fp8"] = Q_fp8.contiguous().to(W.device)
        out[f"{prefix}.Q_scale_inv"] = Q_scale_inv.contiguous().to(W.device)
    return out


# Bytes-per-element by safetensors dtype string. Used so the regenerated
# index's total_size can be computed from header reads alone, without
# loading tensor payloads on the passthrough fast path.
_SAFETENSORS_DTYPE_BYTES: dict[str, int] = {
    "BOOL": 1, "U8": 1, "I8": 1,
    "F8_E4M3": 1, "F8_E5M2": 1, "F8_E4M3FNUZ": 1, "F8_E5M2FNUZ": 1,
    "F16": 2, "BF16": 2, "I16": 2, "U16": 2,
    "F32": 4, "I32": 4, "U32": 4,
    "F64": 8, "I64": 8, "U64": 8,
}  # fmt: skip


def _safetensors_dtype_bytes(dtype_str: str) -> int:
    try:
        return _SAFETENSORS_DTYPE_BYTES[dtype_str]
    except KeyError as exc:
        raise ValueError(
            f"Unknown safetensors dtype {dtype_str!r}; expected one of {sorted(_SAFETENSORS_DTYPE_BYTES)}"
        ) from exc


# Torch → safetensors dtype-string mapping (only the dtypes the converter
# actually emits + reads). Add entries if/when new ones appear in inputs.
# Covers both the IEEE FP8 formats (NVIDIA: e4m3fn, e5m2) and the AMD ROCm
# FNUZ variants (e4m3fnuz, e5m2fnuz). safetensors >= 0.5 supports all four.
_TORCH_TO_SAFETENSORS_DTYPE: dict[torch.dtype, str] = {
    torch.float64: "F64",
    torch.float32: "F32",
    torch.float16: "F16",
    torch.bfloat16: "BF16",
    torch.float8_e4m3fn: "F8_E4M3",
    torch.float8_e5m2: "F8_E5M2",
}
# ROCm "FNUZ" dtypes may be missing on older torch builds (pre-2.4). Guard
# the lookup so we don't fail at import time on a non-ROCm / older torch.
if hasattr(torch, "float8_e4m3fnuz"):
    _TORCH_TO_SAFETENSORS_DTYPE[torch.float8_e4m3fnuz] = "F8_E4M3FNUZ"
if hasattr(torch, "float8_e5m2fnuz"):
    _TORCH_TO_SAFETENSORS_DTYPE[torch.float8_e5m2fnuz] = "F8_E5M2FNUZ"


def _torch_dtype_to_safetensors_str(dtype: torch.dtype) -> str:
    try:
        return _TORCH_TO_SAFETENSORS_DTYPE[dtype]
    except KeyError as exc:
        raise ValueError(
            f"No safetensors dtype string known for torch dtype {dtype}; add it to _TORCH_TO_SAFETENSORS_DTYPE."
        ) from exc


def _read_safetensors_header(path: Path) -> tuple[int, dict]:
    """Return `(header_size, header_dict)`. Payload starts at file offset `8 + header_size`."""
    with path.open("rb") as f:
        size_bytes = f.read(8)
        if len(size_bytes) != 8:
            raise ValueError(f"{path}: truncated safetensors file (header length)")
        header_size = struct.unpack("<Q", size_bytes)[0]
        header_bytes = f.read(header_size)
        if len(header_bytes) != header_size:
            raise ValueError(f"{path}: truncated safetensors file (header body)")
    return header_size, json.loads(header_bytes)


def _encode_safetensors_header(header_dict: dict) -> bytes:
    """JSON-encode + pad to 8-byte alignment (matches safetensors-python convention)."""
    raw = json.dumps(header_dict, separators=(",", ":")).encode("utf-8")
    pad = (-len(raw)) % 8
    return raw + b" " * pad


def _write_tensor_bytes(dst, tensor: torch.Tensor) -> None:
    """Stream a torch tensor's raw bytes into `dst` (zero-copy via ctypes).

    Caller is responsible for tensor being CPU + contiguous; we re-apply
    both to be safe. `dst` must be an open file in binary write mode.
    """
    tensor = tensor.detach().cpu().contiguous()
    nbytes = tensor.numel() * tensor.element_size()
    if nbytes == 0:
        return
    # Build a uint8 ctypes view at the tensor's data pointer; memoryview over
    # that is what `file.write` will consume. Tensor stays alive through the
    # write because it's a local.
    buf = (ctypes.c_ubyte * nbytes).from_address(tensor.data_ptr())
    dst.write(memoryview(buf))


def _build_output_plan(
    in_header: dict,
    in_payload_start: int,
    ranks: dict[str, int],
    q_dtype_str: str,
) -> list[dict]:
    """Walk input header in order; emit ordered output units with assigned offsets.

    Each unit is a dict with `kind` in {"passthrough", "factor"} and the
    fields needed downstream (passthrough: `in_offset`/`in_nbytes` for
    `copy_file_range`; factor: `prefix`/`factor_name` for the decompose step).
    All units carry `out_name`, `out_dtype`, `out_shape`, `out_offset`,
    `out_nbytes` for header assembly + progress updates.
    """
    plan: list[dict] = []
    for in_name, in_info in in_header.items():
        in_dtype = in_info["dtype"]
        in_shape = list(in_info["shape"])
        in_start, in_end = in_info["data_offsets"]
        in_nbytes = in_end - in_start

        if in_name.endswith(".weight"):
            prefix = in_name[: -len(".weight")]
            if prefix in ranks:
                out_d, in_d = in_shape  # weight is (out_features, in_features)
                r = ranks[prefix]  # _validate_ranks enforced r <= min(out_d, in_d)
                factors = (
                    ("A", "BF16", [out_d, r]),
                    ("B", "BF16", [r, in_d]),
                    ("Q_fp8", q_dtype_str, [out_d, in_d]),
                    ("Q_scale_inv", "F32", [1]),
                )
                # is_first / is_last flag the SVD-trigger and cache-eviction
                # points so the consumer loop doesn't infer them from names.
                for i, (name, dtype, shape) in enumerate(factors):
                    plan.append(
                        {
                            "kind": "factor",
                            "out_name": f"{prefix}.{name}",
                            "out_dtype": dtype,
                            "out_shape": shape,
                            "prefix": prefix,
                            "factor_name": name,
                            "is_first": i == 0,
                            "is_last": i == len(factors) - 1,
                        }
                    )
                continue
        plan.append(
            {
                "kind": "passthrough",
                "out_name": in_name,
                "out_dtype": in_dtype,
                "out_shape": in_shape,
                "in_offset": in_payload_start + in_start,
                "in_nbytes": in_nbytes,
            }
        )

    # Assign sequential output offsets + compute output byte sizes
    cursor = 0
    for entry in plan:
        n_elements = math.prod(entry["out_shape"]) if entry["out_shape"] else 1
        nbytes = n_elements * _SAFETENSORS_DTYPE_BYTES[entry["out_dtype"]]
        entry["out_offset"] = cursor
        entry["out_nbytes"] = nbytes
        cursor += nbytes
    return plan


def _plan_to_header(plan: list[dict], metadata: dict[str, str] | None) -> dict:
    header: dict = {}
    if metadata:
        header["__metadata__"] = metadata
    for entry in plan:
        header[entry["out_name"]] = {
            "dtype": entry["out_dtype"],
            "shape": entry["out_shape"],
            "data_offsets": [
                entry["out_offset"],
                entry["out_offset"] + entry["out_nbytes"],
            ],
        }
    return header


def _prepare_output_paths(
    final_path: Path,
    partial_path: Path,
    *,
    overwrite: bool,
    required_bytes: int,
) -> None:
    """Ready the output destination for a convert. Raises on any blocker.

    Checks AND mutates: clears stale staging and ensures the parent dir
    exists, so the caller can proceed straight to writes.

    - `final_path` refuses if it already exists, unless `overwrite=True`.
    - `partial_path` is swept on encounter (no --overwrite gate). The
      `_STAGING_SUFFIX` is unique enough that any match is unambiguously
      our own leftover from a crashed prior run, so eager cleanup is
      safe and saves the user a manual `rm` step.
    - Output parent is created if missing and must be writable (catches
      a read-only parent before a multi-minute SVD has nowhere to land).
    - Free space at the output parent must meet `required_bytes` (input
      size, a safe lower bound for the converted output — factors are
      typically smaller). The system temp dir isn't checked because the
      staging path lives next to the final output.
    """
    if final_path.exists() and not overwrite:
        raise FileExistsError(
            f"Output already exists: {final_path}. Pass `overwrite=True` (CLI: `--overwrite`) or delete it to proceed."
        )

    if partial_path.exists():
        log.info("Removing stale staging path from prior run: %s", partial_path)
        if partial_path.is_dir():
            shutil.rmtree(partial_path)
        else:
            partial_path.unlink()

    try:
        final_path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=final_path.parent, delete=True):
            pass
    except OSError as e:
        raise PermissionError(
            f"Cannot write to output parent {final_path.parent}: {e}"
        ) from e

    free = shutil.disk_usage(final_path.parent).free
    if free < required_bytes:
        raise OSError(
            f"Insufficient disk space at {final_path.parent}: "
            f"free={free} bytes, required>={required_bytes} bytes "
            f"(input size, a safe lower bound for the converted output)."
        )


def convert_safetensors(
    input_path: str | Path,
    output_path: str | Path,
    *,
    layer_regex: str | None = None,
    rank: int | None = None,
    prefix_ranks: dict[str, int] | None = None,
    r_matrices_path: str | Path | None = None,
    lora_paths_and_strengths: Sequence[tuple[str | Path, float]] | None = None,
    q_dtype: torch.dtype = torch.float8_e4m3fn,
    decompose_device: str | torch.device | None = None,
    overwrite: bool = False,
    progress: bool = True,
) -> None:
    """Convert one `.safetensors` file → one `.safetensors` file.

    For a HF-sharded checkpoint, use `convert_sharded_safetensors` with
    the `.safetensors.index.json` index file.

    Streaming I/O: passthrough tensors copy via `os.sendfile` (Linux
    kernel zero-copy), and only the prefixes selected for decomposition
    are loaded into RAM (via `safe_open`). Peak memory ≈ one weight + its
    four factors, regardless of total file size.

    Atomicity: writes go to a sibling `.lite-linear-partial` staging
    file; the final rename is atomic. Refuses to start if `output_path`
    exists (unless `overwrite=True`). A stale staging file from a
    crashed prior run is swept on encounter without an `--overwrite`
    gate (the suffix is unique enough that any match is unambiguously
    ours).

    Renders a progress bar that advances after each chunk hits disk; the
    right-side status flips to `decomposing N/M` while a prefix's SVD runs.
    Pass `progress=False` to silence the bar (library callers).

    Linux-only: relies on `os.sendfile`.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    r_matrices = load_r_matrices(r_matrices_path) if r_matrices_path else None
    lora_specs = _normalize_lora_specs(lora_paths_and_strengths)

    if not input_path.is_file():
        raise FileNotFoundError(f"Input does not exist or is not a file: {input_path}")
    if input_path.suffix.lower() != ".safetensors":
        raise ValueError(
            f"Input must be a `.safetensors` file; got {input_path.name}. "
            f"For a sharded checkpoint, use `convert_sharded_safetensors` "
            f"with the `.safetensors.index.json` file. PyTorch pickle "
            f"checkpoints (.pt / .bin / .pth) aren't supported."
        )

    partial_path = output_path.parent / (output_path.name + _STAGING_SUFFIX)
    _prepare_output_paths(
        output_path,
        partial_path,
        overwrite=overwrite,
        required_bytes=input_path.stat().st_size,
    )

    # Resolve ranks against this file's shapes.
    _, header = _read_safetensors_header(input_path)
    header.pop("__metadata__", None)
    shape_map = {k: tuple(v["shape"]) for k, v in header.items()}
    ranks_dict = _plan_conversion(
        shape_map,
        layer_regex=layer_regex,
        rank=rank,
        prefix_ranks=prefix_ranks,
    )
    log.info("Converting %d prefix(es) from %s", len(ranks_dict), input_path.name)
    total_bytes = input_path.stat().st_size

    try:
        with _ConvertProgress.start(
            output_path.name,
            total_bytes,
            len(ranks_dict),
            disable=not progress,
        ) as progress_state:
            _convert_single_file(
                input_path,
                partial_path,
                ranks=ranks_dict,
                r_matrices=r_matrices,
                lora_specs=lora_specs,
                q_dtype=q_dtype,
                decompose_device=(
                    torch.device(decompose_device)
                    if decompose_device is not None
                    else None
                ),
                progress_state=progress_state,
            )
        partial_path.replace(output_path)
    except BaseException:
        partial_path.unlink(missing_ok=True)
        raise


def _collect_shard_metadata(
    input_dir: Path, by_shard: dict[str, list[str]]
) -> tuple[dict[str, tuple[int, ...]], dict[str, int]]:
    """Header-only pre-pass over every shard: shapes + per-key byte sizes.

    Surfaces misconfig (missing/oddly-typed keys) before any output write.
    `byte_map` later feeds the passthrough fast-path's `total_size`
    accounting in the regenerated index.
    """
    shape_map: dict[str, tuple[int, ...]] = {}
    byte_map: dict[str, int] = {}
    for shard_name, keys in by_shard.items():
        with safe_open(str(input_dir / shard_name), framework="pt", device="cpu") as f:
            for key in keys:
                sl = f.get_slice(key)
                shape = tuple(sl.get_shape())
                shape_map[key] = shape
                byte_map[key] = math.prod(shape) * _safetensors_dtype_bytes(
                    sl.get_dtype()
                )
    return shape_map, byte_map


def _process_shard(
    shard_name: str,
    keys: list[str],
    *,
    input_dir: Path,
    partial_dir: Path,
    ranks: dict[str, int],
    r_matrices: dict[str, torch.Tensor] | None,
    lora_specs: Sequence[_LoraSpec],
    byte_map: dict[str, int],
    q_dtype: torch.dtype,
    decompose_device: torch.device | None = None,
    progress_state: _ConvertProgress,
) -> tuple[list[tuple[str, str]], int]:
    """Convert one shard, picking fast vs slow path by whether any rank applies.

    Returns `(weight_map_additions, payload_bytes_added)` so the caller can
    fold them into the regenerated index.
    """
    # Slice the global ranks dict down to whatever lives in this shard.
    # Empty intersection → shard is untouched by the plan (fast path).
    shard_keyset = set(keys)
    shard_ranks = {p: r for p, r in ranks.items() if f"{p}.weight" in shard_keyset}

    if not shard_ranks:
        progress_state.clear_decompose_status()
        _stream_whole_file(
            input_dir / shard_name,
            partial_dir / shard_name,
            progress_state=progress_state,
        )
        additions = [(key, shard_name) for key in keys]
        return additions, sum(byte_map[key] for key in keys)

    payload_bytes, out_keys = _convert_single_file(
        input_dir / shard_name,
        partial_dir / shard_name,
        ranks=shard_ranks,
        r_matrices=r_matrices,
        lora_specs=lora_specs,
        q_dtype=q_dtype,
        decompose_device=decompose_device,
        progress_state=progress_state,
    )
    return [(key, shard_name) for key in out_keys], payload_bytes


def _write_sharded_index(
    partial_dir: Path,
    index_name: str,
    *,
    weight_map: dict[str, str],
    total_bytes: int,
    input_metadata: dict,
) -> None:
    """Write the regenerated `.safetensors.index.json` inside `partial_dir`.

    Preserves the input index's filename so consumers that hardcode prefixes
    like `diffusion_pytorch_model.*` keep working.
    """
    new_index = {
        "metadata": {**input_metadata, "total_size": total_bytes},
        "weight_map": weight_map,
    }
    with (partial_dir / index_name).open("w") as f:
        json.dump(new_index, f, indent=2, sort_keys=True)


def convert_sharded_safetensors(
    index_path: str | Path,
    output_dir: str | Path,
    *,
    layer_regex: str | None = None,
    rank: int | None = None,
    prefix_ranks: dict[str, int] | None = None,
    r_matrices_path: str | Path | None = None,
    lora_paths_and_strengths: Sequence[tuple[str | Path, float]] | None = None,
    q_dtype: torch.dtype = torch.float8_e4m3fn,
    decompose_device: str | torch.device | None = None,
    overwrite: bool = False,
    progress: bool = True,
) -> None:
    """Convert a HF-sharded checkpoint via its `.safetensors.index.json`.

    `index_path` must end with `.safetensors.index.json`; shards listed in
    its `weight_map` are resolved relative to `index_path.parent`. Output
    goes to `output_dir` (a NEW directory created by this function),
    containing:
      - an index file with the SAME filename as the input index
      - shards with the SAME filenames as the input shards (any subdir
        paths in the input `weight_map` are preserved inside `output_dir`)

    Atomicity: writes go to a sibling `.lite-linear-partial/` staging
    dir; the whole dir is renamed at the end. Refuses to start if
    `output_dir` exists (unless `overwrite=True`). A stale staging dir
    from a crashed prior run is swept on encounter without an
    `--overwrite` gate (the suffix is unique enough that any match is
    unambiguously ours).

    Pass `progress=False` to silence the bar (library callers).

    For a single `.safetensors` file, use `convert_safetensors`.
    """
    index_path = Path(index_path)
    output_dir = Path(output_dir)
    r_matrices = load_r_matrices(r_matrices_path) if r_matrices_path else None
    lora_specs = _normalize_lora_specs(lora_paths_and_strengths)

    if not index_path.is_file():
        raise FileNotFoundError(f"Input does not exist or is not a file: {index_path}")
    if not index_path.name.endswith(".safetensors.index.json"):
        raise ValueError(
            f"Input must be a `.safetensors.index.json` file; got "
            f"{index_path.name}. For a single safetensors file, use "
            f"`convert_safetensors`."
        )

    # Load + minimally validate the index. Malformed JSON propagates a
    # JSONDecodeError; missing shards surface via safe_open later.
    index = json.loads(index_path.read_text())
    weight_map = index.get("weight_map")
    if not isinstance(weight_map, dict) or not weight_map:
        raise ValueError(
            f"{index_path} doesn't look like a safetensors index (missing or empty `weight_map`)."
        )

    input_dir = index_path.parent
    partial_dir = output_dir.parent / (output_dir.name + _STAGING_SUFFIX)
    required = sum(
        (input_dir / shard).stat().st_size for shard in set(weight_map.values())
    )
    _prepare_output_paths(
        output_dir,
        partial_dir,
        overwrite=overwrite,
        required_bytes=required,
    )

    # Group keys by shard so each shard opens once.
    by_shard: dict[str, list[str]] = {}
    for key, shard_name in weight_map.items():
        by_shard.setdefault(shard_name, []).append(key)

    shape_map, byte_map = _collect_shard_metadata(input_dir, by_shard)
    ranks = _plan_conversion(
        shape_map,
        layer_regex=layer_regex,
        rank=rank,
        prefix_ranks=prefix_ranks,
    )
    log.info("Converting %d prefix(es) across %d shard(s)", len(ranks), len(by_shard))

    total_input_bytes = sum(
        (input_dir / shard_name).stat().st_size for shard_name in by_shard
    )

    try:
        partial_dir.mkdir()
        with _ConvertProgress.start(
            output_dir.name,
            total_input_bytes,
            len(ranks),
            disable=not progress,
        ) as progress_state:
            new_weight_map: dict[str, str] = {}
            total_bytes = 0
            for shard_name, keys in by_shard.items():
                additions, added_bytes = _process_shard(
                    shard_name,
                    keys,
                    input_dir=input_dir,
                    partial_dir=partial_dir,
                    ranks=ranks,
                    r_matrices=r_matrices,
                    lora_specs=lora_specs,
                    byte_map=byte_map,
                    q_dtype=q_dtype,
                    decompose_device=(
                        torch.device(decompose_device)
                        if decompose_device is not None
                        else None
                    ),
                    progress_state=progress_state,
                )
                new_weight_map.update(additions)
                total_bytes += added_bytes

            _write_sharded_index(
                partial_dir,
                index_path.name,
                weight_map=new_weight_map,
                total_bytes=total_bytes,
                input_metadata=index.get("metadata", {}),
            )

        # Atomic flip. `_prepare_output_paths` already enforced refuse-on-
        # exists when overwrite=False, so reaching here with output_dir
        # present means the user opted in.
        if output_dir.exists():
            shutil.rmtree(output_dir)
        partial_dir.replace(output_dir)
    except BaseException:
        shutil.rmtree(partial_dir, ignore_errors=True)
        raise


def _copy_passthrough_chunked(
    dst,
    src,
    *,
    entry: dict,
    sync_per_chunk: bool,
    progress_state: _ConvertProgress | None,
) -> None:
    """Copy `entry["in_nbytes"]` bytes from `src` (at `in_offset`) into `dst`.

    Chunked at `_SENDFILE_CHUNK` for snappy ctrl-C and smooth bar advance.
    Linux uses sendfile for zero-copy; macOS / other BSDs fall back to
    pread+write because their sendfile requires the dst fd to be a socket.

    When `sync_per_chunk=True` (callers past the last decompose), each
    chunk fdatasyncs so the bar tracks durable bytes; otherwise writes
    overlap with the next SVD.
    """
    remaining = entry["in_nbytes"]
    src_pos = entry["in_offset"]
    use_sendfile = sys.platform.startswith("linux")
    while remaining:
        n_bytes = min(_SENDFILE_CHUNK, remaining)
        if use_sendfile:
            copied = os.sendfile(dst.fileno(), src.fileno(), src_pos, n_bytes)
        else:
            chunk = os.pread(src.fileno(), n_bytes, src_pos)
            dst.write(chunk)
            copied = len(chunk)
        if copied == 0:
            raise OSError(
                f"sendfile returned 0 with {remaining} bytes left for {entry['out_name']}"
            )
        remaining -= copied
        src_pos += copied
        if sync_per_chunk:
            _fdatasync(dst.fileno())
        if progress_state is not None:
            progress_state.advance(copied)


def _compute_factor_quad(
    W: torch.Tensor,
    *,
    rank: int,
    R: torch.Tensor | None,
    prefix: str,
    loras: Sequence[_OpenLora],
    q_dtype: torch.dtype,
    device: torch.device | None = None,
) -> tuple[dict[str, torch.Tensor], int]:
    """Run decompose_weight and pack the four factors into a contiguous dict.

    Returns `(factor_dict, weight_in_bytes)`; the second value is the input
    weight's byte size for the caller's bar-advance accounting.

    `device` moves the decomposition math (SVD; eigh+sqrt when `R` is given)
    off the CPU. Factors always come back on CPU for the streaming writer.

    SVD factor pairs are not unique across backends (sign/rotation), so
    cross-device equivalence holds for `A @ B` and the quantized `Q`, not for
    `A`/`B` individually.
    """
    # TODO(svd-backend): while the GPU is already much faster than CPU for
    # the full SVD, we might want to explore randomized / truncated SVD,
    # which computes only the top-r singular pair we actually keep instead
    # of the full decomposition.
    input_nbytes = W.numel() * W.element_size()
    if device is not None and device.type != "cpu":
        W = W.to(device)
        R = R.to(device) if R is not None else None
    W = _fuse_lora_weight(W, prefix=prefix, loras=loras)
    A, B, Q_fp8, Q_scale_inv = decompose_weight(
        W,
        rank=rank,
        R=R,
        # `ab_dtype=bf16` matches the fused kernel's required storage dtype.
        ab_dtype=torch.bfloat16,
        q_dtype=q_dtype,
    )
    return (
        {
            "A": A.contiguous().cpu(),
            "B": B.contiguous().cpu(),
            "Q_fp8": Q_fp8.contiguous().cpu(),
            "Q_scale_inv": Q_scale_inv.contiguous().cpu(),
        },
        input_nbytes,
    )


def _convert_single_file(
    input_path: Path,
    output_path: Path,
    *,
    ranks: dict[str, int],
    r_matrices: dict[str, torch.Tensor] | None,
    q_dtype: torch.dtype,
    lora_specs: Sequence[_LoraSpec] = (),
    decompose_device: torch.device | None = None,
    progress_state: _ConvertProgress | None = None,
) -> tuple[int, list[str]]:
    """Stream-convert one safetensors file in → directly to `output_path`.

    Writes go straight to `output_path` (no internal staging temp file).
    The caller is responsible for the atomic-rename pattern: writing to
    a sibling `<final><_STAGING_SUFFIX>` and renaming on success, or
    sweeping the whole enclosing staging dir on failure.

    Passthrough tensors copy via chunked `os.sendfile` (kernel zero-copy,
    same-fs Linux). Decomposed prefixes lazy-load their weight via
    `safe_open`, run SVD, write 4 factors. Peak RAM ≈ one weight + its 4
    factors, regardless of total file size.

    Returns `(output_payload_bytes, output_key_order)` so the sharded
    caller can update its `weight_map` + index `total_size`.
    """
    in_header_size, in_header = _read_safetensors_header(input_path)
    in_payload_start = 8 + in_header_size
    metadata = in_header.pop("__metadata__", None)
    # Input header (8-byte length prefix + JSON header) is consumed by the
    # read above; advance for it so per-tensor advances below sum to total.
    if progress_state is not None:
        progress_state.advance(in_payload_start)

    q_dtype_str = _torch_dtype_to_safetensors_str(q_dtype)
    plan = _build_output_plan(in_header, in_payload_start, ranks, q_dtype_str)
    out_header_bytes = _encode_safetensors_header(_plan_to_header(plan, metadata))
    payload_bytes = sum(e["out_nbytes"] for e in plan)
    out_keys = [e["out_name"] for e in plan]

    # Support subdir paths in sharded `weight_map` (e.g. `sub/shard.safetensors`).
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # `buffering=0` so our `dst.write` and `os.sendfile` both advance the
    # underlying fd position consistently. Buffered IO would interleave the
    # two and write Python's buffer at wrong offsets after sendfile bumps
    # the kernel-side position.
    with (
        ExitStack() as stack,
        safe_open(str(input_path), framework="pt", device="cpu") as f_st,
        input_path.open("rb") as src,
        output_path.open("wb", buffering=0) as dst,
    ):
        dst.write(struct.pack("<Q", len(out_header_bytes)) + out_header_bytes)
        loras = []
        for spec in lora_specs:
            tensors = stack.enter_context(
                safe_open(str(spec.path), framework="pt", device="cpu")
            )
            loras.append(
                _OpenLora(
                    path=spec.path,
                    strength=spec.strength,
                    tensors=tensors,
                    keys=frozenset(tensors.keys()),
                )
            )
        open_loras = tuple(loras)

        # Cache the 4 factors per prefix after the first factor is requested,
        # drop after the last (Q_scale_inv). Bound by one prefix's factors.
        # `weight_in_bytes_cache` holds the *input* weight size for the bar
        # advance — see the Q_scale_inv branch below.
        factor_cache: dict[str, dict[str, torch.Tensor]] = {}
        weight_in_bytes_cache: dict[str, int] = {}
        # Once decompose_remaining hits 0 we're disk-bound: sync per chunk
        # so the bar tracks durability instead of letting a queue build up
        # for the end-of-loop drain.
        decompose_remaining = len(ranks)

        for entry in plan:
            if entry["kind"] == "passthrough":
                if progress_state is not None:
                    progress_state.clear_decompose_status()
                _copy_passthrough_chunked(
                    dst,
                    src,
                    entry=entry,
                    sync_per_chunk=(decompose_remaining == 0),
                    progress_state=progress_state,
                )
            else:  # "factor"
                prefix = entry["prefix"]
                if entry["is_first"]:
                    # First factor of this prefix → run SVD. Right-side
                    # status flips to `decomposing N/M`; bar stays put
                    # (no bytes have hit disk yet).
                    if progress_state is not None:
                        progress_state.announce_decompose()
                    W = f_st.get_tensor(f"{prefix}.weight")
                    R = r_matrices.get(prefix) if r_matrices is not None else None
                    factor_cache[prefix], weight_in_bytes_cache[prefix] = (
                        _compute_factor_quad(
                            W,
                            rank=ranks[prefix],
                            R=R,
                            prefix=prefix,
                            loras=open_loras,
                            q_dtype=q_dtype,
                            device=decompose_device,
                        )
                    )
                _write_tensor_bytes(dst, factor_cache[prefix][entry["factor_name"]])
                if entry["is_last"]:
                    # Bar tracks *input* bytes consumed, so advance by the
                    # original weight size now that all four factors are out.
                    if progress_state is not None:
                        progress_state.advance(weight_in_bytes_cache[prefix])
                    del factor_cache[prefix]
                    del weight_in_bytes_cache[prefix]
                    decompose_remaining -= 1

        # Drain the page cache before close. Usually a no-op (per-chunk
        # sync after the last decompose already drained), but catches the
        # case where decomposes sit at the file tail — without this the
        # bar hits 100% while dirty pages keep flushing and the next
        # prompt appears to hang.

        # TODO(sharded-overlap): in a multi-shard convert this serializes
        # per shard — shard N's drain blocks shard N+1's start, when in
        # principle shard N's writeback could keep running in the
        # background while shard N+1 does its reads + SVDs.
        _fdatasync(dst.fileno())

    return payload_bytes, out_keys


def _stream_whole_file(
    src_path: Path, dst_path: Path, *, progress_state: _ConvertProgress | None
) -> None:
    """Byte-identical chunked sendfile copy of an entire file.

    Writes directly to `dst_path` (no staging temp); caller manages
    cleanup-on-failure via the enclosing staging dir. Advances
    `progress_state` per chunk so the bar moves smoothly through multi-GB
    shards on the sharded passthrough fast path.
    """
    # Support subdir paths in sharded `weight_map`.
    dst_path.parent.mkdir(parents=True, exist_ok=True)
    src_size = src_path.stat().st_size
    with (
        src_path.open("rb") as src,
        dst_path.open("wb", buffering=0) as dst,
    ):
        use_sendfile = sys.platform.startswith("linux")
        remaining = src_size
        while remaining:
            n_bytes = min(_SENDFILE_CHUNK, remaining)
            if use_sendfile:
                # offset=None reads from src's current position and advances it.
                copied = os.sendfile(dst.fileno(), src.fileno(), None, n_bytes)
            else:
                # macOS / BSD: sendfile file-to-file isn't supported, so do the
                # same chunked copy via read+write. src advances its own pos.
                chunk = src.read(n_bytes)
                dst.write(chunk)
                copied = len(chunk)
            if copied == 0:
                raise OSError(
                    f"sendfile returned 0 with {remaining} bytes left copying {src_path}"
                )
            remaining -= copied
            if progress_state is not None:
                progress_state.advance(copied)
        # Drain the kernel page cache before close: writes only reach the
        # page cache, not durable storage, so without fdatasync the bar
        # hits 100% while many GB of dirty pages are still in flight and
        # the user sees a silent freeze before the next prompt.
        _fdatasync(dst.fileno())


__all__ = ["convert_safetensors", "convert_sharded_safetensors"]
