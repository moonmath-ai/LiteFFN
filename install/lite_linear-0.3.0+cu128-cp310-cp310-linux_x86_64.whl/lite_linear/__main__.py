"""Allow `python -m lite_linear ...` to invoke the same CLI as `lite-linear`."""

from .cli import main

if __name__ == "__main__":
    main()
