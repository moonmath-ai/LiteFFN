"""CLI entry points for `lite-linear`."""

import logging
import re
from itertools import groupby
from pathlib import Path
from typing import Annotated, Literal

import torch
from cyclopts import App, ArgumentCollection, Group, Parameter
from cyclopts.types import ExistingFile, ExistingPath, ExistingTomlPath, PositiveInt
from rich import box
from rich.console import Console
from rich.table import Table

from .converter import convert_safetensors, convert_sharded_safetensors
from .inspect import iter_2d_weights
from .linear import PLATFORM_FP8_DTYPE
from .manifest import load_manifest

# Match the prefix the handler-side prints already use.
logging.basicConfig(level=logging.INFO, format="[lite-linear] %(message)s")

# Command docstrings below MUST use numpy-style `Parameters` sections —
# cyclopts derives per-flag `--help` text from them. Other docstring styles
# silently produce empty `--help`.
app = App(name="lite-linear")

_FP8_DTYPE_BY_NAME = {
    "e4m3fn": torch.float8_e4m3fn,
    "e4m3fnuz": torch.float8_e4m3fnuz,
}
_FP8_NAME_BY_DTYPE = {v: k for k, v in _FP8_DTYPE_BY_NAME.items()}


def _detect_fp8_dtype() -> str | None:
    """Return the FP8 variant matching the local GPU, or None if no GPU."""
    if not torch.cuda.is_available():
        return None
    return _FP8_NAME_BY_DTYPE[PLATFORM_FP8_DTYPE]


def _require_exactly_one_selection(argument_collection: ArgumentCollection) -> None:
    """Group validator: require exactly one of `--regex` or `--manifest`."""
    # Custom validator instead of `LimitedChoice(1, 1)`, whose message
    # (`Received 0 arguments: {}. Only [1, 1] choices may be specified.`)
    # is accurate but reads like a bug report.
    populated = argument_collection.filter_by(value_set=True)
    if len(populated) == 1:
        return
    if len(populated) == 0:
        raise ValueError("Specify exactly one of `--regex` or `--manifest`.")
    raise ValueError(
        "`--regex` and `--manifest` are mutually exclusive — pass only one."
    )


_selection_group = Group("selection", validator=_require_exactly_one_selection)


def _output_suffix(
    *,
    rank: int | Literal["mixed"],
    fp8_type: str,
    with_r: bool,
    lora_strength: float | None = None,
) -> str:
    """`-litelinear-r<N>-<fp8>[-calib]` tail appended to default output names.

    `rank` becomes `r{N}` for ints, `r_mixed` for a manifest with mixed ranks.
    """
    rank_part = f"r{rank}" if isinstance(rank, int) else f"r_{rank}"
    parts = [rank_part, fp8_type]
    if lora_strength is not None:
        parts.append(f"lora{lora_strength:g}")
    if with_r:
        parts.append("calib")
    return "-litelinear-" + "-".join(parts)


def _default_single_output(
    input_file: Path,
    *,
    rank: int | Literal["mixed"],
    fp8_type: str,
    with_r: bool,
    lora_strength: float | None = None,
) -> Path:
    """Default `--output` for single-file convert: sibling file with
    `-litelinear-r<N>-<fp8>[-calib]` appended to the stem."""
    suffix = _output_suffix(
        rank=rank,
        fp8_type=fp8_type,
        with_r=with_r,
        lora_strength=lora_strength,
    )
    return input_file.with_name(input_file.stem + suffix + input_file.suffix)


def _default_sharded_output(
    index_file: Path,
    *,
    rank: int | Literal["mixed"],
    fp8_type: str,
    with_r: bool,
    lora_strength: float | None = None,
) -> Path:
    """Default `--output` for sharded convert: sibling directory of the
    index's PARENT dir, with `-litelinear-r<N>-<fp8>[-calib]` appended.

    e.g. `/snap/abc/foo.safetensors.index.json` → `/snap/abc-litelinear-r64-e4m3fn/`.
    """
    # Mirrors how HF distributes converted/quantized model snapshots: the
    # converted twin lives next to the original snapshot dir.
    suffix = _output_suffix(
        rank=rank,
        fp8_type=fp8_type,
        with_r=with_r,
        lora_strength=lora_strength,
    )
    parent_dir = index_file.parent
    return parent_dir.parent / (parent_dir.name + suffix)


def _resolve_fp8(
    fp8_dtype: Literal["e4m3fn", "e4m3fnuz"] | None,
) -> tuple[Literal["e4m3fn", "e4m3fnuz"], torch.dtype]:
    """Resolve `--fp8-dtype` arg (or auto-detect) into (name, torch.dtype).

    Raises SystemExit if the user omitted it AND no GPU is around to detect
    from.
    """
    if fp8_dtype is None:
        detected = _detect_fp8_dtype()
        if detected is None:
            # SystemExit (not ValueError) bypasses the handler's except so the
            # CLI prints a clean stderr line; cyclopts only pretty-prints
            # parse-time errors.
            raise SystemExit(
                "Could not detect GPU type for --fp8-dtype default "
                "(no CUDA / ROCm available). Pass --fp8-dtype e4m3fn "
                "(NVIDIA) or --fp8-dtype e4m3fnuz (AMD ROCm) explicitly."
            )
        print(
            f"[lite-linear] No --fp8-dtype given; defaulting to {detected} based on the local GPU."
        )
        fp8_dtype = detected
    return fp8_dtype, _FP8_DTYPE_BY_NAME[fp8_dtype]


def _rank_summary(
    rank: int,
    manifest: Path | None,
) -> int | Literal["mixed"]:
    """Render the rank component for the default output suffix.

    A uniform `--rank` becomes `rXX`. A `--manifest` whose ranks are all
    identical also becomes `rXX`; a manifest with mixed ranks becomes
    `r_mixed`.
    """
    if manifest is None:
        return rank
    unique = set(load_manifest(manifest).values())
    return next(iter(unique)) if len(unique) == 1 else "mixed"


def _render_inspect_tables(entries: list, *, group_by_file: bool) -> None:
    """Render the per-shard tables and totals line for a non-empty `entries`."""
    console = Console()
    # Per-shard heading + table keeps long filenames out of cramped rows.
    sections: list[tuple[str | None, list]] = (
        [(name, list(g)) for name, g in groupby(entries, key=lambda e: e.file)]
        if group_by_file
        else [(None, entries)]
    )
    for heading, group_entries in sections:
        if heading is not None:
            console.print(f"\n[bold]{heading}[/bold]")
        table = Table(show_header=True, header_style="bold", box=box.SIMPLE_HEAD)
        table.add_column("key", overflow="fold")
        table.add_column("shape", justify="right")
        table.add_column("params", justify="right")
        for e in group_entries:
            table.add_row(
                e.key,
                " x ".join(str(s) for s in e.shape),
                f"{e.num_params:,}",
            )
        console.print(table)

    total = sum(e.num_params for e in entries)
    console.print(f"\n{len(entries)} 2D weight(s), {total:,} total params")


@app.command
def inspect(
    weights: ExistingPath,
    /,
    *,
    regex: str | None = None,
    limit: PositiveInt | None = None,
) -> None:
    r"""List 2D `.weight` keys in a checkpoint with shape and parameter count.

    Useful for hand-crafting `--regex` patterns without grepping source.

    Input dispatch:
      - `.safetensors` file → walk only that file.
      - `.safetensors.index.json` file → walk shards listed in `weight_map`
        (subdir paths inside the index are resolved relative to the index).
      - Directory → walk every `*.safetensors` file in it. Any
        `.safetensors.index.json` in the directory is ignored — point at
        the index file directly if you want indexed semantics.

    Parameters
    ----------
    weights: Path
        `.safetensors` file, `.safetensors.index.json` file, or a directory.
    regex: str
        Optional Python regex matched (via `re.search`, so unanchored)
        against `<prefix>` (key with `.weight` stripped) — same shape as
        `convert --regex` so patterns transfer 1:1. Example: `--regex
        'ff\\.2'` selects `blk.0.ff.2.weight`.
    limit: int
        Show at most N entries.
    """
    weights_path = Path(weights)
    group_by_file = weights_path.is_dir()
    try:
        entries = list(iter_2d_weights(weights_path))
        if not entries:
            print("(no 2D .weight keys)")
            return
        total_2d = len(entries)
        if regex is not None:
            pattern = re.compile(regex)
            entries = [
                e for e in entries if pattern.search(e.key.removesuffix(".weight"))
            ]
        if not entries:
            print(f"(--regex {regex!r} matched 0 of {total_2d} 2D .weight key(s))")
            return
        if limit is not None:
            entries = entries[:limit]
        _render_inspect_tables(entries, group_by_file=group_by_file)
    except Exception as e:
        # Collapse runtime failures (cyclopts only pretty-prints parse errors).
        raise SystemExit(str(e)) from e


@app.command
def convert(
    weights: ExistingFile,
    /,
    *,
    output: Annotated[Path | None, Parameter(alias="-o")] = None,
    rank: int = 64,
    regex: Annotated[str | None, Parameter(group=_selection_group)] = None,
    manifest: Annotated[
        ExistingTomlPath | None, Parameter(group=_selection_group)
    ] = None,
    r_matrices: ExistingFile | None = None,
    lora: ExistingFile | None = None,
    lora_strength: float = 1.0,
    fp8_dtype: Literal["e4m3fn", "e4m3fnuz"] | None = None,
    decompose_device: str = "cpu",
    overwrite: bool = False,
) -> None:
    r"""Decompose selected dense 2D weights in a `.safetensors` file.

    For a HF-sharded checkpoint, use `convert-sharded` with the
    `.safetensors.index.json` index file.

    Writes a new `.safetensors` file with the four LiteLinear factor keys
    (`<prefix>.A`, `.B`, `.Q_fp8`, `.Q_scale_inv`) replacing each
    decomposed `<prefix>.weight`. Non-selected weights pass through
    byte-identical via `os.sendfile`.

    Parameters
    ----------
    weights: Path
        Single `.safetensors` file.
    output: Path
        Output `.safetensors` path. Defaults to a sibling derived from the
        input filename + flags, e.g. `model.safetensors` →
        `model-litelinear-r64-e4m3fn.safetensors`.
    rank: int
        Uniform rank when using --regex. Ignored when --manifest is set.
    regex: str
        Python regex matched (via `re.search`, so unanchored) against
        `<prefix>` (key with `.weight` stripped). Example: `--regex
        'ff\\.[02]'` matches `blk.0.ff.0` and `blk.0.ff.2`. Pass
        `--regex '.*'` to decompose every 2D weight in the checkpoint.
    manifest: Path
        Per-prefix rank manifest TOML (see lite_linear.manifest.save_manifest).
        Mutually exclusive with --regex.
    r_matrices: Path
        Optional .pt or .safetensors mapping `{prefix: R}` for data-aware
        decomposition. Same prefix scheme as the model.
    lora: Path
        Optional LoRA `.safetensors` checkpoint to fuse into selected dense
        weights before decomposition. This is intended for checkpoint
        conversion only; non-selected dense layers remain passthrough and can
        still receive the same LoRA at runtime.
    lora_strength: float
        Strength multiplier for `--lora`. Defaults to 1.0.
    fp8_dtype: str
        FP8 variant for Q. `e4m3fn` for NVIDIA, `e4m3fnuz` for AMD ROCm.
        Defaults to auto-detect based on the local GPU.
    decompose_device: str
        Device for the decomposition math (SVD; eigh when `--r-matrices`
        is given). `cuda` turns hour-scale R-aware converts into minutes;
        factors are moved back to CPU for writing either way. Default `cpu`.
    overwrite: bool
        Clobber an existing `output` if it already exists. Default off.
    """
    weights_path = Path(weights)
    try:
        if weights_path.suffix.lower() != ".safetensors":
            raise ValueError(
                f"`convert` expects a `.safetensors` file; got "
                f"{weights_path.name}. For a sharded checkpoint, use "
                f"`convert-sharded` with the `.safetensors.index.json` file."
            )

        fp8_name, fp8 = _resolve_fp8(fp8_dtype)
        if output is None:
            output = _default_single_output(
                weights_path,
                rank=_rank_summary(rank, manifest),
                fp8_type=fp8_name,
                with_r=r_matrices is not None,
                lora_strength=lora_strength if lora is not None else None,
            )
            print(f"[lite-linear] --output not given; writing to {output}")

        selection: dict[str, object] = (
            {"prefix_ranks": load_manifest(manifest)}
            if manifest is not None
            else {"layer_regex": regex, "rank": rank}
        )
        convert_safetensors(
            weights_path,
            output,
            **selection,
            r_matrices_path=r_matrices,
            lora_paths_and_strengths=(
                [(lora, lora_strength)] if lora is not None else None
            ),
            q_dtype=fp8,
            decompose_device=decompose_device,
            overwrite=overwrite,
        )
    except Exception as e:
        # Collapse runtime failures (cyclopts only pretty-prints parse errors).
        raise SystemExit(str(e)) from e

    print(f"Wrote {output}")


@app.command(name="convert-sharded")
def convert_sharded(
    index: ExistingFile,
    /,
    *,
    output: Annotated[Path | None, Parameter(alias="-o")] = None,
    rank: int = 64,
    regex: Annotated[str | None, Parameter(group=_selection_group)] = None,
    manifest: Annotated[
        ExistingTomlPath | None, Parameter(group=_selection_group)
    ] = None,
    r_matrices: ExistingFile | None = None,
    lora: ExistingFile | None = None,
    lora_strength: float = 1.0,
    fp8_dtype: Literal["e4m3fn", "e4m3fnuz"] | None = None,
    decompose_device: str = "cpu",
    overwrite: bool = False,
) -> None:
    r"""Decompose a HF-sharded checkpoint via its `.safetensors.index.json`.

    Reads the index, processes each shard listed in `weight_map`, and
    writes a new directory containing the same-named index + shards. The
    output directory is created by this command (defaults to a sibling of
    the input's parent directory).

    For a single `.safetensors` file, use `convert` instead.

    Parameters
    ----------
    index: Path
        Path to a `.safetensors.index.json` file. Shards listed in
        `weight_map` are resolved relative to this file's directory.
    output: Path
        Output directory. Defaults to a sibling of the input's parent dir,
        e.g. `/snap/abc/foo.safetensors.index.json` →
        `/snap/abc-litelinear-r64-e4m3fn/`. Must not exist (unless
        --overwrite).
    rank: int
        Uniform rank when using --regex. Ignored when --manifest is set.
    regex: str
        Python regex matched (via `re.search`, so unanchored) against
        `<prefix>` (key with `.weight` stripped). Example: `--regex
        'ff\\.[02]'` matches `blk.0.ff.0` and `blk.0.ff.2`. Pass
        `--regex '.*'` to decompose every 2D weight in the checkpoint.
    manifest: Path
        Per-prefix rank manifest TOML (see lite_linear.manifest.save_manifest).
        Mutually exclusive with --regex.
    r_matrices: Path
        Optional .pt or .safetensors mapping `{prefix: R}` for data-aware
        decomposition. Same prefix scheme as the model.
    lora: Path
        Optional LoRA `.safetensors` checkpoint to fuse into selected dense
        weights before decomposition.
    lora_strength: float
        Strength multiplier for `--lora`. Defaults to 1.0.
    fp8_dtype: str
        FP8 variant for Q. `e4m3fn` for NVIDIA, `e4m3fnuz` for AMD ROCm.
        Defaults to auto-detect based on the local GPU.
    decompose_device: str
        Device for the decomposition math (SVD; eigh when `--r-matrices`
        is given). `cuda` turns hour-scale R-aware converts into minutes;
        factors are moved back to CPU for writing either way. Default `cpu`.
    overwrite: bool
        Clobber an existing `output` directory if it already exists.
        Default off.
    """
    index_path = Path(index)
    try:
        if not index_path.name.endswith(".safetensors.index.json"):
            raise ValueError(
                f"`convert-sharded` expects a `.safetensors.index.json` "
                f"file; got {index_path.name}. For a single safetensors "
                f"file, use `convert`."
            )

        fp8_name, fp8 = _resolve_fp8(fp8_dtype)
        if output is None:
            output = _default_sharded_output(
                index_path,
                rank=_rank_summary(rank, manifest),
                fp8_type=fp8_name,
                with_r=r_matrices is not None,
                lora_strength=lora_strength if lora is not None else None,
            )
            print(f"[lite-linear] --output not given; writing to {output}")

        selection: dict[str, object] = (
            {"prefix_ranks": load_manifest(manifest)}
            if manifest is not None
            else {"layer_regex": regex, "rank": rank}
        )
        convert_sharded_safetensors(
            index_path,
            output,
            **selection,
            r_matrices_path=r_matrices,
            lora_paths_and_strengths=(
                [(lora, lora_strength)] if lora is not None else None
            ),
            q_dtype=fp8,
            decompose_device=decompose_device,
            overwrite=overwrite,
        )
    except Exception as e:
        raise SystemExit(str(e)) from e

    print(f"Wrote {output}")


def main() -> None:
    """Entry point for the `lite-linear` console script."""
    app()


if __name__ == "__main__":
    main()
