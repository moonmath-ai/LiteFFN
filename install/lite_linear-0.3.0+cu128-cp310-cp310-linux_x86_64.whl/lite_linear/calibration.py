r"""Forward-hook calibration: capture R = E[xxᵀ] per layer for R-aware decomposition.

Two pieces:

- :class:`AutocorrAccumulator`: primitive. One layer, one accumulator. Sums
  Σ xᵀx and a row count; ``.r`` returns the normalized fp32 R matrix.
- :class:`Calibrator`: multi-layer context manager. Walks
  ``model.named_modules()``, matches modules by regex + type, registers
  forward-pre hooks at ``__enter__``, removes them at ``__exit__``. Exposes
  ``.accumulators`` for DDP / resume code and ``.r_matrices()`` for the
  consumer-side normalized output.

Capture is decoupled from the model's forward signature: hooks fire on the
matched ``nn.Module`` s, the user runs whatever ``model(...)`` shape their model
needs inside the ``with`` block. Works for tensor-only diffusion DiTs (Wan,
Hunyuan), structured-input multimodal (LTX-2), and HF LLMs alike.

Overcollect by default. Capture is expensive; filtering at convert time is
free. The default regex selects anything inside a ``ModuleList`` /
``Sequential`` (any FQN component is a digit), which catches FFN / attention
linears across the diffusers convention (``transformer_blocks.N.*``), the HF
convention (``layers.N.*``), and the bare-Wan convention (``blocks.N.*``).
"""

from __future__ import annotations

import re
import warnings
from pathlib import Path
from typing import TYPE_CHECKING

import torch
from safetensors import safe_open
from safetensors.torch import save_file
from torch import nn

from .linear import LiteLinear

if TYPE_CHECKING:
    from typing import Self

    from torch.utils.hooks import RemovableHandle

# File-format version stored in safetensors metadata under the key below.
# Bump on any on-disk shape change; `load_r_matrices` strict-checks on read.
_FORMAT_VERSION = "1"
_VERSION_KEY = "lite_linear_r_matrices_version"


class AutocorrAccumulator:
    """Σ xᵀx + row count for one layer's input stream.

    Public fields ``.xtx`` (storage dtype, shape ``(dim, dim)``) and
    ``.n_rows`` are exposed for DDP all-reduce and checkpoint resume;
    operate on them directly, no helper API needed.
    """

    def __init__(
        self,
        dim: int,
        *,
        device: torch.device | str = "cpu",
        dtype: torch.dtype = torch.float64,
    ) -> None:
        self.dim = int(dim)
        self.xtx = torch.zeros((self.dim, self.dim), device=device, dtype=dtype)
        self.n_rows: int = 0

    @torch.no_grad()
    def update(self, x: torch.Tensor) -> None:
        """Accumulate xᵀx and row count from ``x: (..., dim)``.

        The last dim must match ``self.dim``; everything else is flattened.
        Input is cast to fp32 before the outer product; the result is
        accumulated into the storage dtype (fp64 by default).
        """
        if x.shape[-1] != self.dim:
            raise ValueError(
                f"x.shape[-1]={x.shape[-1]} does not match AutocorrAccumulator.dim={self.dim}"
            )
        x2d = (
            x.detach()
            .reshape(-1, self.dim)
            .to(device=self.xtx.device, dtype=torch.float32)
        )
        self.xtx += (x2d.transpose(0, 1) @ x2d).to(dtype=self.xtx.dtype)
        self.n_rows += x2d.shape[0]

    @property
    def r(self) -> torch.Tensor:
        """Normalized R = xtx / n_rows in fp32. Raises if no rows accumulated."""
        if self.n_rows <= 0:
            raise RuntimeError(
                "AutocorrAccumulator has no input rows; cannot compute R. Did the hooked module fire during forward?"
            )
        return (self.xtx / float(self.n_rows)).to(dtype=torch.float32)


_DEFAULT_REGEX = r"\b\d+\b"
_DEFAULT_LAYER_TYPES: tuple[type, ...] = (nn.Linear, LiteLinear)


class Calibrator:
    r"""Context-managed multi-layer R-matrix capture via forward-pre hooks.

    Discovery runs at ``__init__``: ``model.named_modules()`` is walked,
    modules matching ``regex`` (via ``re.search``, so unanchored) and
    ``layer_types`` (and not in ``layer_types_exclude``) each get an
    :class:`AutocorrAccumulator`. Hooks register at ``__enter__`` and remove
    at ``__exit__``.

    ``regex`` is matched against the module FQN from ``named_modules()``:
    the same string used as the ``<prefix>`` for ``lite-linear convert
    --regex``, so a regex written for one transfers 1:1 to the other.
    Default ``r"\b\d+\b"`` matches any FQN containing a digit-indexed
    component (anything inside a ``ModuleList`` / ``Sequential``). Pass
    ``regex='.*'`` for every matching module.

    For tensor-parallel codebases (Megatron-style ``ColumnParallelLinear`` /
    ``RowParallelLinear``) extend ``layer_types`` to include those classes;
    they are not subclasses of ``nn.Linear`` and would otherwise be missed.

    Accumulators persist across ``__exit__``; re-entering the context resumes
    accumulation on the same state. Construct a new ``Calibrator`` for fresh
    state. ``with`` blocks must not be nested on the same instance.

    Example::

        with Calibrator(model) as cal:
            for batch in data_iter:
                model(batch)
        r_matrices = cal.r_matrices()
    """

    def __init__(
        self,
        model: nn.Module,
        *,
        regex: str = _DEFAULT_REGEX,
        layer_types: tuple[type, ...] = _DEFAULT_LAYER_TYPES,
        layer_types_exclude: tuple[type, ...] = (),
        accumulator_dtype: torch.dtype = torch.float64,
        accumulator_device: torch.device | str = "cpu",
    ) -> None:
        self.model = model
        self.regex = regex
        self.layer_types = layer_types
        self.layer_types_exclude = layer_types_exclude

        pattern = re.compile(regex)
        self._matched: dict[str, nn.Module] = {}
        for fqn, mod in model.named_modules():
            if not isinstance(mod, layer_types):
                continue
            if layer_types_exclude and isinstance(mod, layer_types_exclude):
                continue
            if not pattern.search(fqn):
                continue
            self._matched[fqn] = mod
        if not self._matched:
            raise ValueError(
                f"regex {regex!r} matched no modules of types {layer_types!r} "
                f"(excluding {layer_types_exclude!r}) in the model"
            )

        self._accumulators: dict[str, AutocorrAccumulator] = {}
        for fqn, mod in self._matched.items():
            if not hasattr(mod, "in_features"):
                raise TypeError(
                    f"matched module {fqn!r} ({type(mod).__name__}) has no "
                    "`in_features` attribute; cannot size the accumulator. "
                    "Use a custom `layer_types` whose members expose `in_features`."
                )
            self._accumulators[fqn] = AutocorrAccumulator(
                mod.in_features,
                device=accumulator_device,
                dtype=accumulator_dtype,
            )

        self._handles: list[RemovableHandle] = []

    @property
    def accumulators(self) -> dict[str, AutocorrAccumulator]:
        """{fqn: AutocorrAccumulator}. Stable identity across __enter__/__exit__."""
        return self._accumulators

    def r_matrices(self) -> dict[str, torch.Tensor]:
        """{fqn: R_fp32} for accumulators with ``n_rows > 0``.

        Empty accumulators (conditional branches not exercised during
        capture) are skipped with a single ``RuntimeWarning`` naming them.
        """
        populated: dict[str, torch.Tensor] = {}
        empty: list[str] = []
        for fqn, acc in self._accumulators.items():
            if acc.n_rows > 0:
                populated[fqn] = acc.r
            else:
                empty.append(fqn)
        if empty:
            preview = ", ".join(empty[:5])
            tail = f", ... ({len(empty)} total)" if len(empty) > 5 else ""
            warnings.warn(
                f"{len(empty)} accumulator(s) saw no input during capture; "
                f"skipped from r_matrices(): {preview}{tail}. "
                "If unexpected, check the model's forward control flow.",
                RuntimeWarning,
                stacklevel=2,
            )
        return populated

    def __enter__(self) -> Self:
        if self._handles:
            raise RuntimeError(
                "Calibrator hooks are already active; exit the existing context before re-entering."
            )
        for fqn, mod in self._matched.items():
            acc = self._accumulators[fqn]
            self._handles.append(mod.register_forward_pre_hook(_make_hook(acc)))
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        for handle in self._handles:
            handle.remove()
        self._handles.clear()

    def save(self, path: str | Path) -> None:
        """Save this Calibrator's accumulators to ``path`` as safetensors.

        Sugar over :func:`save_calibration_state`.
        """
        save_calibration_state(path, self._accumulators)

    def restore(self, path: str | Path) -> None:
        """Restore raw state from ``path`` into this Calibrator's accumulators.

        Sugar over :func:`restore_calibration_state`.
        """
        restore_calibration_state(path, self._accumulators)


def _make_hook(acc: AutocorrAccumulator):
    """Build a forward-pre-hook closure that feeds the layer's input to ``acc.update``."""

    @torch.no_grad()
    def hook(module: nn.Module, args: tuple) -> None:
        acc.update(args[0])

    return hook


# ---------- file I/O ----------
#
# On-disk shape (safetensors):
#   {
#     "<fqn>.xtx":    Tensor (dim, dim) in accumulator dtype,
#     "<fqn>.n_rows": Tensor (1,) int64,
#     ...
#   }
# Metadata: {"lite_linear_r_matrices_version": "1"}.
#
# One file format serves two consumers:
# - `load_r_matrices` normalizes R = xtx / n_rows in fp32 for the converter.
# - `restore_calibration_state` copies raw (xtx, n_rows) into existing
#   accumulators for checkpoint resume.


def save_calibration_state(
    path: str | Path,
    accumulators: dict[str, AutocorrAccumulator],
) -> None:
    """Save raw ``(xtx, n_rows)`` per FQN as safetensors.

    Empty accumulators (``n_rows == 0``) are skipped. Raises
    :class:`ValueError` if no populated accumulators remain.

    See :meth:`Calibrator.save` for the common single-Calibrator case.
    """
    flat: dict[str, torch.Tensor] = {}
    for fqn, acc in accumulators.items():
        if acc.n_rows <= 0:
            continue
        flat[f"{fqn}.xtx"] = acc.xtx.detach().cpu()
        flat[f"{fqn}.n_rows"] = torch.tensor([acc.n_rows], dtype=torch.int64)
    if not flat:
        raise ValueError("no populated accumulators to save (all have n_rows == 0)")
    save_file(flat, str(path), metadata={_VERSION_KEY: _FORMAT_VERSION})


def load_r_matrices(path: str | Path) -> dict[str, torch.Tensor]:
    """Load and normalize ``R = xtx / n_rows``. Returns ``{fqn: R_fp32}``.

    Strict on file format: missing or wrong version raises; unknown or
    unpaired keys raise. Lazy load via ``safe_open``: one source tensor
    in RAM at a time, not the whole file.
    """
    path = Path(path)
    with safe_open(str(path), framework="pt", device="cpu") as f:
        _check_version(path, f.metadata() or {})
        xtx_fqns, n_rows_fqns = _validate_keys(path, list(f.keys()))
        out: dict[str, torch.Tensor] = {}
        for fqn in sorted(xtx_fqns):
            xtx = f.get_tensor(f"{fqn}.xtx")
            n_rows = int(f.get_tensor(f"{fqn}.n_rows").item())
            if n_rows <= 0:
                raise ValueError(f"{path}: {fqn}.n_rows = {n_rows} (must be > 0)")
            out[fqn] = (xtx / float(n_rows)).to(dtype=torch.float32)
    return out


def restore_calibration_state(
    path: str | Path,
    accumulators: dict[str, AutocorrAccumulator],
) -> None:
    """Copy saved ``(xtx, n_rows)`` into existing accumulators in-place.

    FQNs in the file that don't match a key in ``accumulators`` are silently
    skipped (resume with a narrower regex is valid). Accumulators with no
    matching key in the file are left at their current state.

    Shape / dtype mismatches between the file and the accumulator raise
    via ``copy_``; this catches "wrong checkpoint paired with this model"
    early.

    See :meth:`Calibrator.restore` for the common single-Calibrator case.
    """
    path = Path(path)
    with safe_open(str(path), framework="pt", device="cpu") as f:
        _check_version(path, f.metadata() or {})
        keys = set(f.keys())
        for fqn, acc in accumulators.items():
            xtx_key = f"{fqn}.xtx"
            if xtx_key not in keys:
                continue
            loaded = f.get_tensor(xtx_key)
            acc.xtx.copy_(loaded.to(device=acc.xtx.device, dtype=acc.xtx.dtype))
            acc.n_rows = int(f.get_tensor(f"{fqn}.n_rows").item())


def _check_version(path: Path, metadata: dict) -> None:
    version = metadata.get(_VERSION_KEY)
    if version is None:
        raise ValueError(
            f"{path}: missing `{_VERSION_KEY}` metadata; this does not look like a lite-linear R-matrix file."
        )
    if version != _FORMAT_VERSION:
        raise ValueError(
            f"{path}: unknown {_VERSION_KEY}={version!r}; "
            f"expected {_FORMAT_VERSION!r}. "
            "(Was this file produced by a newer lite-linear?)"
        )


def _validate_keys(path: Path, keys: list[str]) -> tuple[set[str], set[str]]:
    """Validate keys match the `<fqn>.xtx` + `<fqn>.n_rows` pair convention.

    Returns the (xtx_fqns, n_rows_fqns) sets, guaranteed equal.
    """
    xtx_fqns = {k[: -len(".xtx")] for k in keys if k.endswith(".xtx")}
    n_rows_fqns = {k[: -len(".n_rows")] for k in keys if k.endswith(".n_rows")}
    unknown = [k for k in keys if not k.endswith((".xtx", ".n_rows"))]
    if unknown:
        raise ValueError(
            f"{path}: unrecognized keys (not `.xtx` / `.n_rows`): {sorted(unknown)[:5]}"
        )
    unpaired_xtx = xtx_fqns - n_rows_fqns
    unpaired_n = n_rows_fqns - xtx_fqns
    if unpaired_xtx or unpaired_n:
        raise ValueError(
            f"{path}: unpaired keys; xtx without n_rows: "
            f"{sorted(unpaired_xtx)[:5]}; "
            f"n_rows without xtx: {sorted(unpaired_n)[:5]}"
        )
    return xtx_fqns, n_rows_fqns
